//
//  profileView.swift
//  Wisata
//
//  Created by Naufal Gagambani Sumbi on 14/04/21.
//

import SwiftUI

struct profileView: View {
    var body: some View {
        NavigationView {
        Form{
            Section{
            
                HStack{
            Image("Convertible")
                .resizable()
                .clipShape(Circle())
                .frame(width: 75, height: 75, alignment: .center)
                    VStack{
                Text("DaBaby")
                    .font(.headline)
                    .fontWeight(.medium)
                    .multilineTextAlignment(.leading)
                        Text("Convertible")
                            .font(.subheadline)
                
                
            }
                }
                .padding(.bottom)
                .padding(.top)
                HStack{
                    Image(systemName: "person.circle")
                        .resizable()
                        .frame(width: 20, height: 20, alignment: .leading)
                    
                        Text("Profile Settings")
                            .font(.headline)
                            .fontWeight(.medium)
                            .frame(width: 200, height: 40, alignment: .leading)
                                
                        
        
        }
                HStack{
                    
                    Image(systemName: "wrench")
                        .resizable()
                        .frame(width: 20, height: 20, alignment: .leading)
                        Text("Account Settings")
                            .font(.headline)
                            .fontWeight(.medium)
                            .frame(width: 200, height: 40, alignment: .leading)
                                
                        
        
        }
                HStack{
                    Image(systemName: "questionmark.circle")
                        .resizable()
                        .frame(width: 20, height: 20, alignment: .leading)
                        Text("Help")
                            .font(.headline)
                            .fontWeight(.medium)
                            .frame(width: 200, height: 40, alignment: .leading)
                                
                        
        
        }
                HStack{
                    Image(systemName: "tray")
                        .resizable()
                        .frame(width: 20, height: 20, alignment: .leading)
                        Text("Forum")
                            .font(.headline)
                            .fontWeight(.medium)
                            .frame(width: 200, height: 40, alignment: .leading)
                                
                        
        
        }
                HStack{
                    Image(systemName: "star")
                        .resizable()
                        .frame(width: 20, height: 20, alignment: .center)
                        Text("Rate Us")
                            .font(.headline)
                            .fontWeight(.medium)
                            .frame(width: 200, height: 40, alignment: .leading)
        }
                HStack{
                    Image(systemName: "arrow.uturn.left")
                        .resizable()
                        .frame(width: 20, height: 20, alignment: .center)
                        Text("Log Out")
                            .font(.headline)
                            .fontWeight(.medium)
                            .frame(width: 200, height: 40, alignment: .leading)
                    
                }
            }
        }
        .navigationBarTitle(Text("Profile"))
        }
    }
}

struct profileView_Previews: PreviewProvider {
    static var previews: some View {
        profileView()
    }
}

