//
//  wisataView.swift
//  Wisata
//
//  Created by Naufal Gagambani Sumbi on 19/04/21.
//

import SwiftUI

struct wisataView: View {
    
    let dataWisata : wisata
    
    var body: some View {
            ScrollView{
                VStack(alignment: .leading){
                    Image(dataWisata.gambar)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .ignoresSafeArea()
                    Spacer()
                    Text(dataWisata.namaWisata)
                        .font(.title)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                    Spacer()
                    Text(dataWisata.negara)
                        .font(.headline)
                    Spacer()
                    HStack{
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                        Text("rating:  \(dataWisata.bintang)")
                            .font(.body)
                            .fontWeight(.medium)
                    }
                    Spacer()
                    Text(dataWisata.detail)
                            .font(.body)
                            .fontWeight(.regular)
                            .frame(width: 400)
                    
                    
                }
                
            }
            
        
    }
}

struct wisataView_Previews: PreviewProvider {
    static var previews: some View {
        wisataView(dataWisata: wisata(id: 0, namaWisata: "", gambar: "", bintang: "", negara: "", detail: ""))
    }
}
