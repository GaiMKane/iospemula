//
//  ContentView.swift
//  Wisata
//
//  Created by Naufal Gagambani Sumbi on 13/04/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            ListWisata()
                .tabItem{
                    Image(systemName: "house.fill")
                    Text("Beranda")
                }
            profileView()
                .tabItem{
                    Image(systemName: "person")
                    Text("Profile")
                }
            lol()
                .tabItem {
                    Image(systemName: "book")
                    Text("Booking")
                }
            
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
