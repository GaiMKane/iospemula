//
//  home.swift
//  Wisata
//
//  Created by Naufal Gagambani Sumbi on 13/04/21.
//

import SwiftUI

struct ListWisata: View {
    var body: some View {
        NavigationView{
            List(file){ data in
                NavigationLink(
                    destination: wisataView(dataWisata: data)){
                    ZStack{
                        Image("white")
                            .cornerRadius(10)
                            .padding(.top)
                            .padding(.bottom)
                        HStack{
                            Image(data.gambar)
                                .resizable()
                                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                                .cornerRadius(10)
                            VStack(alignment: .leading){
                                Text(data.namaWisata)
                                    .font(.title)
                                    .fontWeight(.bold)
                                Text(data.negara)
                                HStack{
                                    Image(systemName: "star.fill")
                                        .foregroundColor(.yellow)
                                    Text(data.bintang)
                                }
                                
                                
                            }
                            
                        }
                        
                    }
                    
                    
                }
                
            }
            .navigationBarTitle(Text("Wisata"))
        }
        
    }
}

struct home_Previews: PreviewProvider {
    static var previews: some View {
        ListWisata()
    }
}

