//
//  lol.swift
//  Wisata
//
//  Created by Naufal Gagambani Sumbi on 19/04/21.
//

import SwiftUI

struct lol: View {
    var body: some View {
        VStack{
            Image(systemName:("airplane"))
                .resizable()
                .frame(width: 150, height: 150, alignment: .center)
            Text("Coming soon!")
                .font(.largeTitle)
                .fontWeight(.bold)
        }
    }
}

struct lol_Previews: PreviewProvider {
    static var previews: some View {
        lol()
    }
}
