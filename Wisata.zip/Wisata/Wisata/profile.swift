//
//  profile.swift
//  Wisata
//
//  Created by Naufal Gagambani Sumbi on 14/04/21.
//

import SwiftUI

struct profile: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct profile_Previews: PreviewProvider {
    static var previews: some View {
        profile()
    }
}
