//
//  WisataData.swift
//  Wisata
//
//  Created by Naufal Gagambani Sumbi on 13/04/21.
//

struct wisata : Identifiable{
    let id : Int
    let namaWisata : String
    let gambar : String
    let bintang : String
    let negara : String
    let detail : String
    
}
